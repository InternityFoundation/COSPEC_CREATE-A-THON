package tech.spirit.woshield;

import android.app.Application;

import com.google.firebase.auth.FirebaseUser;

public class Application_Class extends Application {

public static FirebaseUser firebaseUser;
    @Override
    public void onCreate() {
        super.onCreate();



    }
}
